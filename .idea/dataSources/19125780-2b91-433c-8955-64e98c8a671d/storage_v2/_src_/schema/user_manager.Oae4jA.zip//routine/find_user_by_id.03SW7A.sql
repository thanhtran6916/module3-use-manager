create
    definer = root@localhost procedure find_user_by_id(IN idInput int)
begin
    select * from user where id = idInput;
end;

